﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome05
{
    public partial class Form1 : Form
    {
        bool Cekker = false;
        Dictionary<string, int> counters = new Dictionary<string, int>();
        Dictionary<string, string> categoryMap = new Dictionary<string, string>();
        DataTable Produk_Simpan;
        DataTable Produk_Tampil;
        DataTable Category;
        public Form1()
        {

            
            InitializeComponent();
            Produk_Simpan = new DataTable();
            Produk_Tampil = new DataTable();
            Category = new DataTable();
            Produk_Simpan.Columns.Add("ID Product");
            Produk_Simpan.Columns.Add("Nama Product");
            Produk_Simpan.Columns.Add("Harga");
            Produk_Simpan.Columns.Add("Stock");
            Produk_Simpan.Columns.Add("ID Catagory");

            Produk_Simpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            Produk_Simpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            Produk_Simpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            Produk_Simpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            Produk_Simpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            Produk_Simpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            Produk_Simpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            Produk_Simpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");


            DGW_Product.DataSource = Produk_Simpan;
            DGW_Product.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            Category.Columns.Add("ID Category");
            Category.Columns.Add("Name Category");

            Category.Rows.Add("C1", "Jas");
            Category.Rows.Add("C2", "T-Shirt");
            Category.Rows.Add("C3", "Rok");
            Category.Rows.Add("C4", "Celana");
            Category.Rows.Add("C5", "Cawat");

            DGW_Category.DataSource = Category;
            DGW_Product.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;



            foreach (DataRow row in Category.Rows)
            {
                CB_Details_Category.Items.Add(row["Name Category"].ToString());
            }

            counters["R"] = 2;
            counters["J"] = 2;
            counters["T"] = 2;
            counters["C"] = 2;

            //CB_Filter.DataSource = Category.Columns;
            foreach (DataRow row in Category.Rows)
            {
                CB_Filter.Items.Add(row["Name Category"]);
            }
            CB_Filter.Enabled = false;


        }
        private void DGW_Product_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string Nama = DGW_Product.SelectedRows[0].Cells[1].Value.ToString();
            string Harga = DGW_Product.SelectedRows[0].Cells[2].Value.ToString();
            string Stock = DGW_Product.SelectedRows[0].Cells[3].Value.ToString();
            string IDCategory = DGW_Product.SelectedRows[0].Cells[4].Value.ToString();

            TB_Details_Nama.Text = Nama;
            TB_Details_Harga.Text = Harga;
            TB_Details_Stock.Text = Stock;


            foreach (DataRow row in Category.Rows)
            {
                if (row["ID Category"].ToString() == IDCategory)
                {
                    CB_Details_Category.Text = row["Name Category"].ToString();
                    break;
                }
            }



        }
        private void AddCategory(string categoryName)
        {
            if (!string.IsNullOrEmpty(categoryName) && !Category.AsEnumerable().Any(c => c.Field<string>("Name Category") == categoryName))
            {
                string maxId = Category.AsEnumerable().Max(c => c.Field<string>("ID Category")).Substring(1);
                string categoryId = "C" + (int.Parse(maxId) + 1).ToString("D1");

                Category.Rows.Add(categoryId, categoryName);

                CB_Filter.Items.Add(categoryName);
                CB_Details_Category.Items.Add(categoryName);
            }
            else
            {
                MessageBox.Show("Kategori sudah ada atau nama kategori tidak boleh kosong.", "Kategori gagal ditambahkan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BT_Catagory_Add_Click(object sender, EventArgs e)
        {
            string categoryName = TB_Category_Nama.Text.Trim();
            AddCategory(categoryName);
            DGW_Category.Refresh();
            TB_Category_Nama.Clear();
        }


        private void BT_Catagory_Remove_Click(object sender, EventArgs e)
        {

            //        string hapus = DGW_Category.CurrentRow.Cells[0].Value.ToString();

            //        foreach (DataGridViewRow row in DGW_Category.SelectedRows)
            //        {
            //            DGW_Category.Rows.Remove(row);
            //        }

            //        for (int i = Produk_Simpan.Rows.Count - 1; i >= 0; i--)
            //        {
            //            if (Produk_Simpan.Rows[i][4] == hapus)
            //            {
            //                DGW_Product.Rows.RemoveAt(i);
            //            }
            //        }

        }




        private void BT_Details_Remove_Click(object sender, EventArgs e)
        {
            if (DGW_Product.SelectedRows.Count > 0)
            {
                string code = DGW_Product.SelectedRows[0].Cells[0].Value.ToString();
                string firstLetter = code.Substring(0, 1).ToUpper();

                if (counters.ContainsKey(firstLetter))
                {
                    counters[firstLetter]--;
                }

                DGW_Product.Rows.RemoveAt(DGW_Product.SelectedRows[0].Index);
            }
        }

        private void BT_Details_Add_Click(object sender, EventArgs e)
        {
            if (Cekker = true)
            {
                MessageBox.Show("blm diisi");
            }
            else
            {
                Cekker = false;
                string Code = GenerateCode(TB_Details_Nama.Text);
                string Category1 = CB_Details_Category.Text;
                string ID = "";
                for (int i = 0; i < Category.Rows.Count; i++)
                {
                    if (Category.Rows[i][1].ToString().Contains(CB_Details_Category.Text))
                    {
                        ID = Category.Rows[i][0].ToString();
                    }
                }


                Produk_Simpan.Rows.Add($"{Code}", $"{Category1}", $"{TB_Details_Harga.Text}", $"{TB_Details_Stock.Text}", $"{ID}");
            }
            
        }

        string GenerateCode(string itemName)
        {
            string firstLetter = itemName.Substring(0, 1).ToUpper();
            if (!counters.ContainsKey(firstLetter))
            {
                counters[firstLetter] = 1;
            }
            else
            {
                counters[firstLetter]++;
            }


            return firstLetter + counters[firstLetter].ToString("D3");
        }
        private void cek()
        {
            if (TB_Details_Nama.Text == "")
            {
                MessageBox.Show("blm diisi");
                Cekker = true;
            }
            else if (CB_Details_Category.SelectedItem == null)
            {
                MessageBox.Show("blm diisi");
                Cekker = true;
            }
            else if (TB_Details_Harga.Text == "")
            {
                MessageBox.Show("blm diisi");
                Cekker = true;
            }
            else if (TB_Details_Stock.Text == "")
            {
                MessageBox.Show("blm diisi");
                Cekker = true;
            }
        }
        private void BT_Details_Edit_Click(object sender, EventArgs e)
        {
            if (Cekker = true)
            {
                MessageBox.Show("blm diisi");
            }
            else
            {
                Cekker = false;
                string Code = GenerateCode(TB_Details_Nama.Text);
                string Category1 = CB_Details_Category.Text;
                string ID = "";
                for (int i = 0; i < Category.Rows.Count; i++)
                {
                    if (Category.Rows[i][1].ToString().Contains(CB_Details_Category.Text))
                    {
                        ID = Category.Rows[i][0].ToString();
                    }
                }

                int rowIndex = DGW_Product.SelectedRows[0].Index;
                DataRow row = Produk_Simpan.Rows[rowIndex];

                row["Nama Product"] = TB_Details_Nama.Text;
                row["Harga"] = TB_Details_Harga.Text;
                row["Stock"] = TB_Details_Stock.Text;
                row["ID Catagory"] = ID;

                if (int.Parse(TB_Details_Stock.Text) == 0)
                {
                    string code = DGW_Product.SelectedRows[0].Cells[0].Value.ToString();
                    string firstLetter = code.Substring(0, 1).ToUpper();

                    if (counters.ContainsKey(firstLetter))
                    {
                        counters[firstLetter]--;
                    }

                    DGW_Product.Rows.RemoveAt(DGW_Product.SelectedRows[0].Index);
                }

                DGW_Product.Refresh();
            }
            
        }

        private void CB_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {

            Produk_Tampil.Clear();

  
            if (!Produk_Tampil.Columns.Contains("ID Product"))
            {
                Produk_Tampil.Columns.Add("ID Product", typeof(string));
            }
            if (!Produk_Tampil.Columns.Contains("Nama Product"))
            {
                Produk_Tampil.Columns.Add("Nama Product", typeof(string));
            }
            if (!Produk_Tampil.Columns.Contains("Harga"))
            {
                Produk_Tampil.Columns.Add("Harga", typeof(string));
            }
            if (!Produk_Tampil.Columns.Contains("Stock"))
            {
                Produk_Tampil.Columns.Add("Stock", typeof(string));
            }
            if (!Produk_Tampil.Columns.Contains("ID Catagory"))
            {
                Produk_Tampil.Columns.Add("ID Catagory", typeof(string));
            }


            List<string> selectedCategories = new List<string>();
            if (CB_Filter.SelectedItem != null && CB_Filter.SelectedItem.ToString() != "All Categories")
            {
                selectedCategories.Add(CB_Filter.SelectedItem.ToString());
            }

            if (selectedCategories.Count == 0)
            {
                Produk_Tampil = Produk_Simpan.Copy();
            }
            else
            {
                string categoryID = GetCategoryID(selectedCategories[0]);
                if (!string.IsNullOrEmpty(categoryID))
                {
                    foreach (DataRow row in Produk_Simpan.Rows)
                    {
                        if (row["ID Catagory"].ToString() == categoryID)
                        {
                            Produk_Tampil.Rows.Add(row["ID Product"].ToString(), row["Nama Product"].ToString(), row["Harga"].ToString(), row["Stock"].ToString(), row["ID Catagory"].ToString());
                        }
                    }
                }
            }

            DGW_Product.DataSource = Produk_Tampil;
            DGW_Product.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private string GetCategoryID(string categoryName)
        {
            foreach (DataRow row in Category.Rows)
            {
                if (row["Name Category"].ToString().Equals(categoryName))
                {
                    return row["ID Category"].ToString();
                }
            }

            return "";
        }

        private void BT_All_Click(object sender, EventArgs e)
        {
            CB_Filter.SelectedItem = null;
            Produk_Tampil.Clear();
            Produk_Tampil = Produk_Simpan.Copy();
            DGW_Product.DataSource = Produk_Tampil;
            DGW_Product.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            CB_Filter.Enabled = false; 
        }

        private void DGW_Category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string Nama = DGW_Category.SelectedRows[0].Cells[1].Value.ToString();

            TB_Category_Nama.Text = Nama;
        }

        private void CB_Details_Category_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void DGW_Product_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BT_Filter_Click(object sender, EventArgs e)
        {
            CB_Filter.Enabled = true;
        }
    }
}
