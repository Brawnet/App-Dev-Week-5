﻿namespace TakeHome05
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.DGW_Product = new System.Windows.Forms.DataGridView();
            this.DGW_Category = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TB_Details_Nama = new System.Windows.Forms.TextBox();
            this.TB_Details_Harga = new System.Windows.Forms.TextBox();
            this.TB_Details_Stock = new System.Windows.Forms.TextBox();
            this.CB_Details_Category = new System.Windows.Forms.ComboBox();
            this.TB_Category_Nama = new System.Windows.Forms.TextBox();
            this.CB_Filter = new System.Windows.Forms.ComboBox();
            this.BT_All = new System.Windows.Forms.Button();
            this.BT_Filter = new System.Windows.Forms.Button();
            this.BT_Details_Add = new System.Windows.Forms.Button();
            this.BT_Details_Edit = new System.Windows.Forms.Button();
            this.BT_Details_Remove = new System.Windows.Forms.Button();
            this.BT_Catagory_Add = new System.Windows.Forms.Button();
            this.BT_Catagory_Remove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DGW_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGW_Category)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Product";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(520, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 289);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Details";
            // 
            // DGW_Product
            // 
            this.DGW_Product.AllowUserToAddRows = false;
            this.DGW_Product.AllowUserToDeleteRows = false;
            this.DGW_Product.AllowUserToResizeColumns = false;
            this.DGW_Product.AllowUserToResizeRows = false;
            this.DGW_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGW_Product.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.DGW_Product.Location = new System.Drawing.Point(32, 48);
            this.DGW_Product.MultiSelect = false;
            this.DGW_Product.Name = "DGW_Product";
            this.DGW_Product.RowHeadersVisible = false;
            this.DGW_Product.RowHeadersWidth = 51;
            this.DGW_Product.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.DGW_Product.RowTemplate.Height = 24;
            this.DGW_Product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGW_Product.Size = new System.Drawing.Size(380, 238);
            this.DGW_Product.StandardTab = true;
            this.DGW_Product.TabIndex = 3;
            this.DGW_Product.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGW_Product_CellClick);
            this.DGW_Product.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGW_Product_CellContentClick);
            // 
            // DGW_Category
            // 
            this.DGW_Category.AllowUserToAddRows = false;
            this.DGW_Category.AllowUserToDeleteRows = false;
            this.DGW_Category.AllowUserToResizeColumns = false;
            this.DGW_Category.AllowUserToResizeRows = false;
            this.DGW_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGW_Category.Location = new System.Drawing.Point(525, 48);
            this.DGW_Category.MultiSelect = false;
            this.DGW_Category.Name = "DGW_Category";
            this.DGW_Category.RowHeadersVisible = false;
            this.DGW_Category.RowHeadersWidth = 51;
            this.DGW_Category.RowTemplate.Height = 24;
            this.DGW_Category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGW_Category.Size = new System.Drawing.Size(280, 192);
            this.DGW_Category.TabIndex = 4;
            this.DGW_Category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGW_Category_CellClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 333);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Nama :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 368);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 16);
            this.label5.TabIndex = 6;
            this.label5.Text = "Catagory :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(46, 403);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "Harga :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(50, 436);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 16);
            this.label7.TabIndex = 8;
            this.label7.Text = "Stock :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(522, 253);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 16);
            this.label9.TabIndex = 10;
            this.label9.Text = "Nama :";
            // 
            // TB_Details_Nama
            // 
            this.TB_Details_Nama.Location = new System.Drawing.Point(103, 330);
            this.TB_Details_Nama.Name = "TB_Details_Nama";
            this.TB_Details_Nama.Size = new System.Drawing.Size(309, 22);
            this.TB_Details_Nama.TabIndex = 11;
            // 
            // TB_Details_Harga
            // 
            this.TB_Details_Harga.Location = new System.Drawing.Point(103, 403);
            this.TB_Details_Harga.Name = "TB_Details_Harga";
            this.TB_Details_Harga.Size = new System.Drawing.Size(100, 22);
            this.TB_Details_Harga.TabIndex = 13;
            // 
            // TB_Details_Stock
            // 
            this.TB_Details_Stock.Location = new System.Drawing.Point(103, 436);
            this.TB_Details_Stock.Name = "TB_Details_Stock";
            this.TB_Details_Stock.Size = new System.Drawing.Size(100, 22);
            this.TB_Details_Stock.TabIndex = 14;
            // 
            // CB_Details_Category
            // 
            this.CB_Details_Category.FormattingEnabled = true;
            this.CB_Details_Category.Location = new System.Drawing.Point(103, 365);
            this.CB_Details_Category.Name = "CB_Details_Category";
            this.CB_Details_Category.Size = new System.Drawing.Size(121, 24);
            this.CB_Details_Category.TabIndex = 15;
            this.CB_Details_Category.SelectedIndexChanged += new System.EventHandler(this.CB_Details_Category_SelectedIndexChanged);
            // 
            // TB_Category_Nama
            // 
            this.TB_Category_Nama.Location = new System.Drawing.Point(578, 253);
            this.TB_Category_Nama.Name = "TB_Category_Nama";
            this.TB_Category_Nama.Size = new System.Drawing.Size(227, 22);
            this.TB_Category_Nama.TabIndex = 16;
            // 
            // CB_Filter
            // 
            this.CB_Filter.FormattingEnabled = true;
            this.CB_Filter.Location = new System.Drawing.Point(291, 18);
            this.CB_Filter.Name = "CB_Filter";
            this.CB_Filter.Size = new System.Drawing.Size(121, 24);
            this.CB_Filter.TabIndex = 17;
            this.CB_Filter.SelectedIndexChanged += new System.EventHandler(this.CB_Filter_SelectedIndexChanged);
            // 
            // BT_All
            // 
            this.BT_All.Location = new System.Drawing.Point(185, 19);
            this.BT_All.Name = "BT_All";
            this.BT_All.Size = new System.Drawing.Size(39, 23);
            this.BT_All.TabIndex = 18;
            this.BT_All.Text = "All";
            this.BT_All.UseVisualStyleBackColor = true;
            this.BT_All.Click += new System.EventHandler(this.BT_All_Click);
            // 
            // BT_Filter
            // 
            this.BT_Filter.Location = new System.Drawing.Point(228, 19);
            this.BT_Filter.Name = "BT_Filter";
            this.BT_Filter.Size = new System.Drawing.Size(57, 23);
            this.BT_Filter.TabIndex = 19;
            this.BT_Filter.Text = "Filter :";
            this.BT_Filter.UseVisualStyleBackColor = true;
            this.BT_Filter.Click += new System.EventHandler(this.BT_Filter_Click);
            // 
            // BT_Details_Add
            // 
            this.BT_Details_Add.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Details_Add.Location = new System.Drawing.Point(228, 406);
            this.BT_Details_Add.Name = "BT_Details_Add";
            this.BT_Details_Add.Size = new System.Drawing.Size(67, 52);
            this.BT_Details_Add.TabIndex = 20;
            this.BT_Details_Add.Text = "ADD PRODUCT";
            this.BT_Details_Add.UseVisualStyleBackColor = true;
            this.BT_Details_Add.Click += new System.EventHandler(this.BT_Details_Add_Click);
            // 
            // BT_Details_Edit
            // 
            this.BT_Details_Edit.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Details_Edit.Location = new System.Drawing.Point(301, 406);
            this.BT_Details_Edit.Name = "BT_Details_Edit";
            this.BT_Details_Edit.Size = new System.Drawing.Size(69, 52);
            this.BT_Details_Edit.TabIndex = 21;
            this.BT_Details_Edit.Text = "EDIT PRODUCT";
            this.BT_Details_Edit.UseVisualStyleBackColor = true;
            this.BT_Details_Edit.Click += new System.EventHandler(this.BT_Details_Edit_Click);
            // 
            // BT_Details_Remove
            // 
            this.BT_Details_Remove.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Details_Remove.Location = new System.Drawing.Point(376, 406);
            this.BT_Details_Remove.Name = "BT_Details_Remove";
            this.BT_Details_Remove.Size = new System.Drawing.Size(66, 52);
            this.BT_Details_Remove.TabIndex = 22;
            this.BT_Details_Remove.Text = "REMOVE PRODUCT";
            this.BT_Details_Remove.UseVisualStyleBackColor = true;
            this.BT_Details_Remove.Click += new System.EventHandler(this.BT_Details_Remove_Click);
            // 
            // BT_Catagory_Add
            // 
            this.BT_Catagory_Add.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Catagory_Add.Location = new System.Drawing.Point(578, 300);
            this.BT_Catagory_Add.Name = "BT_Catagory_Add";
            this.BT_Catagory_Add.Size = new System.Drawing.Size(79, 52);
            this.BT_Catagory_Add.TabIndex = 23;
            this.BT_Catagory_Add.Text = "ADD CATAGORY";
            this.BT_Catagory_Add.UseVisualStyleBackColor = true;
            this.BT_Catagory_Add.Click += new System.EventHandler(this.BT_Catagory_Add_Click);
            // 
            // BT_Catagory_Remove
            // 
            this.BT_Catagory_Remove.Font = new System.Drawing.Font("Microsoft Tai Le", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Catagory_Remove.Location = new System.Drawing.Point(663, 300);
            this.BT_Catagory_Remove.Name = "BT_Catagory_Remove";
            this.BT_Catagory_Remove.Size = new System.Drawing.Size(74, 52);
            this.BT_Catagory_Remove.TabIndex = 24;
            this.BT_Catagory_Remove.Text = "REMOVE CATAGORY";
            this.BT_Catagory_Remove.UseVisualStyleBackColor = true;
            this.BT_Catagory_Remove.Click += new System.EventHandler(this.BT_Catagory_Remove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(852, 484);
            this.Controls.Add(this.BT_Catagory_Remove);
            this.Controls.Add(this.BT_Catagory_Add);
            this.Controls.Add(this.BT_Details_Remove);
            this.Controls.Add(this.BT_Details_Edit);
            this.Controls.Add(this.BT_Details_Add);
            this.Controls.Add(this.BT_Filter);
            this.Controls.Add(this.BT_All);
            this.Controls.Add(this.CB_Filter);
            this.Controls.Add(this.TB_Category_Nama);
            this.Controls.Add(this.CB_Details_Category);
            this.Controls.Add(this.TB_Details_Stock);
            this.Controls.Add(this.TB_Details_Harga);
            this.Controls.Add(this.TB_Details_Nama);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.DGW_Category);
            this.Controls.Add(this.DGW_Product);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.DGW_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGW_Category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView DGW_Product;
        private System.Windows.Forms.DataGridView DGW_Category;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TB_Details_Nama;
        private System.Windows.Forms.TextBox TB_Details_Harga;
        private System.Windows.Forms.TextBox TB_Details_Stock;
        private System.Windows.Forms.ComboBox CB_Details_Category;
        private System.Windows.Forms.TextBox TB_Category_Nama;
        private System.Windows.Forms.ComboBox CB_Filter;
        private System.Windows.Forms.Button BT_All;
        private System.Windows.Forms.Button BT_Filter;
        private System.Windows.Forms.Button BT_Details_Add;
        private System.Windows.Forms.Button BT_Details_Edit;
        private System.Windows.Forms.Button BT_Details_Remove;
        private System.Windows.Forms.Button BT_Catagory_Add;
        private System.Windows.Forms.Button BT_Catagory_Remove;
    }
}

